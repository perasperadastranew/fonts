Important:

Shortcuts to additional glyphs such as hearts are stated in 5.png.
Automatic crossbar I placement requires the OpenType Contextual Ligature feature to be enabled (see character panel).



General:

Hey, Codecy here. Thanks for checking out the font! 
It has taken me yet another whole year to release another font. Though in fact I've already started on Starstreak right after I put out Amraam.
This time I wanted to make a proper comic font that can be used for speech bubbles or narration.
Much of this font was referrenced from CC WildWords and Troubleside.

What's a "Starstreak"?
Well… Just like CDX Sidewinder and Amraam again, I've named this after yet another missile, the Starstreak MANPAD.
I've just decided to continue to stick to the theme. Moreover the font name is basically free for the taking.

Anyway, thanks once again for downloading this font! If you do use it, I'd personally like to see it in use! So do contact me about it!



License Information:

CDX Starstreak is a font from Codex, designed by Codecy in 2023. All rights reserved.

CDX Starstreak is FREE for both personal and commercial use.
Any unauthorized monetized redistribution of such is legible to be actioned upon according to the law.
This font is protected by the SIL Open Font License (OFL), read more:
https://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL