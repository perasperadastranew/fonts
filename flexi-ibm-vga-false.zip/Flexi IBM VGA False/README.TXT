
           _ ─ --- ─                  _ ─ --- ─
        .∙"    ,┬,   ~=╥_    .∙.   .∙"          ~=╥_
      .    . .OZZZO╕    ^g,      .    .■°~°■.      ^%╖   .s%ZO┐
          `  └ªqZpª' °∙  `Z,         `        _.,·  `gZ┐  ∙:ZZ|
      _┬g%%oc,  ~ _.,  `  ╘Z;         _.,┬⌐y%Z=-:· .s%Z%L, `OZZYi%g┬_
     jOZZÿÿZZOL· jOZZÿ¬,  `Zb  _.┬⌐y%ZZZZZZZZ%=:∙ jZZZZZZZb `ZZZZÿZZZb
    ∙ZZ?~ ~\ZZZ| |¢ZZZZO\ ·?Z.∙%ÿZZZZZZª*╩ⁿ^°"`' /ZZª"~"ªZZ\ ∙T   ~!ZZ┤
     Z6f   ∙ZZZO∙·|ZZZ^ZZi ]Z1·:-":ZZZ'      _. ∙OZ/     \ZZL :    |6Z'
 .   `ZZ¬._ ~"^Z| ∙ZZZ;\ZZ ╞Z╡   ·¢ZZZ·  _┬%ZZ· l%! .oZo, ]ZZ·∙  _╥ZZ'   .
  ,    ~^╩*╩^~.Z¢··ZZZl ZZ┬ZZ1 · ∙ZZZZ∙  ^ª!ZZ∙ :=l dZZZb ∙ZZ|  ~^"~
   ∙        g%ZZZ··ZZZZ `¥ZZZ° : ·ZZZZ:   ∙lZZ| ∙;∙ :ZZZF ·ZZ|         .'
    ~─_    ·ZZZZ| ∙ZZZZ  └ZZÿ' ∙  ?ZZZ!    :ZZ│· ·∙  "ª"  dZg·      _─~
       ~"^ :ZZZO∙∙|ZZZ!   `^'  '  `¥ZZZ    ·ªZZ:  ·     ./ZZf ·─--`~
           OZZZ∙ jZª╩~  `. _ _. .   ~^ªL, YZZZZOzz┬┬ ·∙:=CO/
     -V!  jª╩^~     .     ~-║∙-~    .     `^╩ªZ¥ÿZF'·∙:%CG' . O R G
                     ~─_    T    _─~             ~'  '^"~
                        ~"═=|=═"~
                            ∙        p r e s e n t s
                            ·


                         FLEXI IBM VGA FONTS  /  v2.0


    Scalable TrueType fonts based on the iconic hardware VGA character set

    ______________________________________________________________________
   


INCLUDED FONTS:

* Flexi IBM VGA False:      Uncorrected aspect ratio, extended character set
* Flexi IBM VGA False 437:  Uncorrected aspect ratio, CP437/DOS encoding


ASPECT RATIO:

  The 'False' versions are not aspect-corrected - they follow the forms of the
  VGA characters as if they used square pixels.  To match the original pixel
  aspect (as seen on 4:3 monitors), see the 'Flexi IBM VGA True' fonts.


SUPPORTED SCRIPTS:

* "Flexi IBM VGA False" - an extended character set, mostly based on various
                          code-pages from DOS (including Greek, Hebrew, 
                          Cyrillic and many Latin scripts, box/block drawing 
                          symbols, math and so on).

* "Flexi IBM VGA False (437)" - contains only the characters from the original
                                IBM PC code page 437 ("US-Latin").  Windows 
                                detects it as 'OEM/DOS', so it's suitable for 
                                your favorite .NFO viewer, or wherever you need
                                the 8-bit DOS encoding.

LICENSE:

  These fonts are released under the Creative Commons Attribution-ShareAlike
  4.0 International license: http://creativecommons.org/licenses/by-sa/4.0/

_________________________________________

// VileR    2020-11    https://int10.org
